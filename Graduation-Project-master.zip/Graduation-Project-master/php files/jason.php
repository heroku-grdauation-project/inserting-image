<?php
require_once("junloc.php");
$jason = new junloc();
$jason->select();
?>